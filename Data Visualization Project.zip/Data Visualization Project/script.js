/*

"javascript.js" - Javascript
Jaxen Sandland, jsandland@stpeterschools.org
https://www.federalreserve.gov/paymentsystems/coin_calprint.htm
*/
/*
function display() {
    // Set graph margins and dimensions
    var margin = {top: 20, right: 20, bottom: 30, left: 40},
        width = 960 - margin.left - margin.right,
        height = 500 - margin.top - margin.bottom;

    var barPadding = 1;

    // Set ranges
    var x = d3.scaleBand()
            .range([0, width])
            .padding(0.1);
    var y = d3.scaleLinear()
            .range([height, 0]);
    var svg = d3.select("body").append("svg")
        .attr("width", width + margin.left + margin.right)
        .attr("height", height + margin.top + margin.bottom)
    .append("g")
        .attr("transform", 
            "translate(" + margin.left + "," + margin.top + ")");

    // Get data
    d3.csv("amounts.csv").then(function(data) {

    // Format data
    data.forEach(function(d) {
        d.amounts = +d.amounts;
    });

    // Scale the range of the data in the domains
    x.domain(data.map(function(d) { return d.year; }));
    y.domain([0, d3.max(data, function(d) { return d.amounts; })]);

    // Append rectangles for bar chart
    svg.selectAll(".bar")
        .data(data)
        .enter().append("rect")
        .attr("class", "bar")
        .attr("x", function(d) { return x(d.year); })
        .attr("width", x.bandwidth())
        .attr("y", function(d) { return y(d.amounts); })
        .attr("height", function(d) { return height - y(d.amounts); });


    // Add x axis
    svg.append("g")
        .attr("transform", "translate(0," + height + ")")
        .call(d3.axisBottom(x));

    // Add y axis
    svg.append("g")
        .call(d3.axisLeft(y));

    });

    svg.selectAll("g")
           .data(data)
           .enter()
           .append("g")
           .append("rect")
           .attr("x", function(d, i) {
                return i * (w / data.length);
           })
           .attr("y", function(d) {
                return h - (d * 4);
           })
           .attr("width", w / data.length - barPadding)
           .attr("height", function(d) {
                return d * 4;
           })
           .attr("fill", function(d) {
                return "rgb(0, 0, " + (d * 10) + ")";
           })
           .append("text")
           .text(function(d) {                 
                    return d.amounts;
           })
           .attr("text-anchor", "middle")
           .attr("x", function(d, i) {
                return i * (w / data.length) + (w / data.length - barPadding) / 2;
           })
           .attr("y", function(d) {
                return h - (d * 4) + 14;
           })
           .attr("font-family", "sans-serif")
           .attr("font-size", "11px")
           .attr("fill", "white");

           svg.selectAll(".text")        
           .data(data)
           .enter()
           .append("text")
           .attr("class","label")
           .attr("x", (function(d) { return x(d.year); }  ))
           .attr("y", function(d) { return y(d.amounts) - 20; })
           .attr("dy", ".75em")
           .text(function(d) { return d.value; });   
           
           

    
}
*/
/*

const data = [50, 123, 126, 157, 140, 146, 170, 166, 224, 213, 165, 386, 321, 130, 203, 216, 179, 265, 173, 216, 319];
const label = ["2001", "2002", "2003", "2004", "2005", "2006", "2007", "2008", "2009", "2010", "2011", "2012", "2013", "2014", "2015", "2016", "2017", "2018", "2019", "2020", "2021"];


*/

// Code goes here

var margin = {top: 20, right: 20, bottom: 70, left: 40},
width = 600 - margin.left - margin.right,
height = 300 - margin.top - margin.bottom;

// Parse the date / time
var	parseDate = d3.timeParse("%Y");

var x = d3.scaleBand().rangeRound([0, width]).paddingInner(0.05);

var y = d3.scaleLinear().range([height, 0]);

var xAxis = d3.axisBottom(x)
.tickFormat(d3.timeFormat("%Y"));

var yAxis = d3.axisLeft(y)
.ticks(10);

var svg = d3.select("body").append("svg")
.attr("width", width + margin.left + margin.right)
.attr("height", height + margin.top + margin.bottom)
.append("g")
.attr("transform",
      "translate(" + margin.left + "," + margin.top + ")");

d3.csv("bar-data.csv", function(error, data) {

data.forEach(function(d) {
    d.date = parseDate(d.date);
    d.value = +d.value;
});

x.domain(data.map(function(d) { return d.date; }));
y.domain([0, d3.max(data, function(d) { return d.value; })]);

svg.append("g")
  .attr("class", "x axis")
  .attr("transform", "translate(0," + height + ")")
  .call(xAxis)
.selectAll("text")
  .style("text-anchor", "end")
  .attr("dx", "-.3em")
  .attr("transform", "rotate(-45)" );

svg.append("g")
  .attr("class", "y axis")
  .call(yAxis)
.append("text")
  .attr("transform", "rotate(-90)")
  .attr("y", 6)
  .attr("dy", ".71em")
  .style("text-anchor", "end")
  .text("Value ($)");

svg.selectAll("bar")
    .data(data)
    .enter().append("rect")
    .style("fill", "steelblue")
    .attr("x", function(d) { return x(d.date); })
    .attr("width", x.bandwidth())
    .attr("y", function(d) { return y(d.value); })
    .attr("height", function(d) { return height - y(d.value); })
    .on("mouseover", function(d) {
    d3.select(this).style("fill", "dodgerblue");
    })
    .on("mouseout", function(d) {
    d3.select(this).style("fill", "steelblue");
    });
  

  svg.selectAll(".text")  		
    .data(data)
    .enter()
    .append("text")
    .attr("class","label")
    .style('fill', 'white')
    .style("text-anchor", "middle")
    .attr("x", (function(d) { return x(d.date) + 11.5; }  ))
    .attr("y", function(d) { return y(d.value) + 4; })
    .attr("dy", ".75em")
    .text(function(d) { return d.value; })


    svg.selectAll("text")
    .data(data)
    .enter()
    .append("text")
    .text(function(d) {
    return d.value;
    })
    .attr("text-anchor", "middle")
    .attr("fill", "white")
    .attr("x", function(d, i) {
    return i * (width / data.length);
    })
    .attr("y", function(d) {
    return height - (d * 4);
    });   

  var all = document.getElementsByClassName("label");
  for (let a of all) {
    a.onselectstart = () => { return false; }
  }
});